Installation
============

Install `Composer`_ and run the following command to get the latest version:

.. code-block:: bash

    composer require "twig/twig:^3.0"

.. _`Composer`: https://getcomposer.org/download/
